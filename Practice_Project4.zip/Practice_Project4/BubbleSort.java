package Practice_Project4;

public class BubbleSort {
	
	public static void swap(int[]arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	
	public static void sort(int arr[]) {
		int n = arr.length;
		
		for(int i =0; i< n-1; i++) {
			boolean swapped = false;
			for(int j = 0; j< n-i-1; j++) {
				if(arr[j+1] < arr[j])
					swapped = true;
					swap(arr, j+1, j);
			}
			if(!swapped) 
				break;
		}
	}
	
	public static void print(int[] arr) {
		int n = arr.length;
		for(int i=0; i<n ;i++) {
			System.out.print(arr[i]+ " ");
			
		}System.out.println();
	}

	public static void main(String[] args) {
		BubbleSort ob = new BubbleSort();
		int arr[] = {64, 25, 12, 22, 11};
		
		System.out.print("Original Array: ");
		ob.print(arr);
		ob.sort(arr);
		
		System.out.print("Sorted Array: ");
		ob.print(arr);
	}

}
