package Practice_Project4;

public class QuickSort {
	public static void swap(int[]arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	
	public static int partition(int[] arr, int l, int h) {
		int pivot = arr[h];
		
		int small = (l-1);
		
		for(int j=l; j<h; j++) {
			if(arr[j] < pivot) {
				small++;
				swap(arr, small, j);
			}
		}
		swap(arr, small+1, h);
		return (small+1);
	}
	
	public static void sort(int arr[], int l, int h) {
		if(l<h) {
			
			int pi = partition(arr, l, h);
			
			sort(arr, l, pi-1);
			sort(arr, pi+1, h);
		}
	}
	
	public static void print(int[] arr) {
		int n = arr.length;
		for(int i=0; i<n ;i++) {
			System.out.print(arr[i]+ " ");
			
		}System.out.println();
	}

	public static void main(String[] args) {
		QuickSort ob = new QuickSort();
		int arr[] = {10,7,8,9,1,5};
		int n = arr.length;
		
		System.out.print("Original Array: ");
		ob.print(arr);
		
		ob.sort(arr, 0, n-1);
		
		System.out.print("Sorted Array: ");
		ob.print(arr);
	}

}
