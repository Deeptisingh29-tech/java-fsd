package Practice_Project4;

public class LinearSearch {
	
	static void linearSearch(int arr[], int n) {
		int k = 50;
		for(int i =0; i<n; i++) {
			if(arr[i] == k ) {
				System.out.println("Element found at index "+i);
			}
		}
		return;
	}

	public static void main(String[] args) {
		int array[] = {10, 20, 50, 40, 80};
		int n = array.length;
		
		linearSearch(array, n);

	}

}
