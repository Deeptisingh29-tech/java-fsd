package Practice_Project2;

public class Finally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hii");
		try {
			int res = 10/1;
			System.out.println("No exception");
		}
		catch(Exception e) {
			System.out.println("catch");
		}
		finally {
			System.out.println("finally");
		}
		System.out.println("end");
	}

}
