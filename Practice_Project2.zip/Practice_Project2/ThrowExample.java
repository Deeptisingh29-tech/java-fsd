package Practice_Project2;

class MyException extends Exception{
	public MyException() {
		
	}
	public MyException(String msg) {
		super(msg);						//passing this message to Exception parameter constructor to set the message.
	}
}

public class ThrowExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =10;
		int b = 5;
		try {
			if(a>b)
				//throw new Exception();			//used to create an exception explicitly
				//throw new Exception("a>b");		//giving the message to the exception
				//throw new ArithmeticException();	//we can also throw the exception according to our requirement
				//throw new ArithmeticException("a>b"); //predefined exception with custom message
				//throw new MyException();			//custom exception 
				throw new MyException("a>b");		//custom exception with custom message
			
			
			else
				System.out.println("noooo");
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}

	}

}
