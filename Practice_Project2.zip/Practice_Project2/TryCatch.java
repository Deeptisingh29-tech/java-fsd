package Practice_Project2;

public class TryCatch {

	public static void main(String[] args) {
		int a = 10;
		int b = 0;
		int arr[] = {10, 20, 30, 40};
		
		try {
			//int ans = a/b;
			//System.out.println(ans);
			
			int ans = arr[6];
			System.out.println(ans);
		}
		catch(Exception e) {
			//System.out.println(e.getMessage());			//predefined name	
			System.out.println(e.toString());			//exception name and message
		}
	}

}
