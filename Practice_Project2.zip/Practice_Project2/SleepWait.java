package Practice_Project2;

public class SleepWait {
	private static Object LOCK = new Object();
	public static void main(String[] args) throws Exception {
		
		Thread t = Thread.currentThread();
		for(int i =1; i<=5; i++) {
			System.out.println("i = "+i);
			if(i==2) {
				Thread.sleep(2000);
				System.out.println("Thread "+t.getName()+" is woken after sleeping for 2 secs.");
			}
			if(i==4) {
				LOCK.wait();
				System.out.println("Object"+LOCK+"is started after waiting for 2 secs.");
			}
			
		}

	}

}
