package Practice_Project2;

class Thread1 extends Thread{		//extending Thread class

	@Override
	public void run() {
		System.out.println("This is a thread that extends Thread class");		
		//super.run();
	}
	
}

class Thread2 implements Runnable{		//implementing runnable

	@Override
	public void run() {
		System.out.println("This is a thread that implements runnable");
		
	}
	
}

public class ThreadExtendImplement {

	public static void main(String[] args) {
		
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();
		
		Thread tt = new Thread(t2);			//making thread class reference because object of runnable doesn't start directly
		
		
		tt.start();
		t1.start();
		

	}

}
