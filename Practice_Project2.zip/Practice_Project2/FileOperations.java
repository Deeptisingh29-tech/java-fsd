package Practice_Project2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class FileOperations {

	public static void main(String[] args) throws Exception {
		
		// Taking the value through keyboard and display on console
		
//		DataInputStream dis = new DataInputStream(System.in);
//		PrintStream ps = System.out;
//		ps.println("Enter the name");
//		String name = dis.readLine();
//		ps.println("Your name is "+name);
//		
		
		
		//Taking data from keyboard and store it in a file
		
//		DataInputStream dis = new DataInputStream(System.in);
//		FileOutputStream fos = new FileOutputStream("abc.txt");
//		int ch;
//		
//		System.out.println("Enter the data");
//		while((ch = dis.read()) !='@') {
//			fos.write(ch);
//		}
//		fos.close();
//		System.out.println("Data Stored Successfully");
		
		
		// Copy from one file to another
//		FileInputStream fis = new FileInputStream("E:\\Eclipse\\TextFileHandling1.txt");
//		FileOutputStream fos =new FileOutputStream("F:\\FileHandling.txt");
//		
//		int ch;
//		while((ch = fis.read()) != -1) {	//-1 represents EOF
//			fos.write(ch);
//		}
//		fis.close();
//		fos.close();
//		System.out.println("file copied");
		
		
		
		//Copy the file to another file using buffer
		FileInputStream fis =new FileInputStream("E:\\Eclipse\\TextFileHandling1.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		FileOutputStream fos = new FileOutputStream("E:\\Eclipse\\TextFileHandling2.txt");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		
		int ch;
		while((ch = bis.read()) != -1) {
			bos.write(ch);
		}
		
		bos.flush();		//it will send the data from buffer to the output file.
		fis.close();
		fos.close();
		System.out.println("Copied");
		
	}

}
