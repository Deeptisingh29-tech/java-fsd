package Practice_Project2;

//here dispaly2 is caller method of display1
//main is caller method of display2
//jvm is caller for main
//throws Exception will pass the execution to caller method of that method

public class ThrowsExample {
	static void display1() throws Exception			//passing the execution to caller method(display2) of that method(display1)
	{
		//try {
			int a = 10/0 ;
		//}
		//catch(Exception e) {}
		//int a = 10/0;
		System.out.println("display1");
	}
	
	static void display2() throws Exception			//passing the execution to caller method(main) of that method(display2)
	{
		//try {
		display1();								
		//}
		//catch(Exception e) {}
		//display1();
		System.out.println("display2");
	}
	public static void main(String[] args) throws Exception  {		//passing the execution to jvm of that method(main)
		// TODO Auto-generated method stub
		//try {
		display2();
		//}
		//catch(Exception e) {}
		System.out.println("main");

	}

}
