package Practice_Project2;

class Booking implements Runnable{
	int avl = 1;
	// To make all the resources available for single thread at a time,
	//synchronization is used.
	@Override
	public synchronized void run() {			//method is synchronized so it will make use of all resources for an object at once
		Thread tt = Thread.currentThread();
		String name = tt.getName();
		if(avl == 1) {						// suing this logic everything works properly but resource is only one and all three of them are getting tickets 
			System.out.println(name + " got the ticket.");
			avl = avl- 1;
		}
		else {
			System.out.println(name + " sorry");
		}
		
	}
	
}

public class Synchronization {

	public static void main(String[] args) {
		Booking b1 =new Booking();		//we are making only one memory becoz avl = 1 only
		
		Thread t1 = new Thread(b1);
		Thread t2 = new Thread(b1);
		Thread t3 = new Thread(b1);
		
		t1.setName("Raj");
		t2.setName("Raju");
		t3.setName("Pankaj");
		
		t1.start();
		t2.start();
		t3.start();
	}

}
