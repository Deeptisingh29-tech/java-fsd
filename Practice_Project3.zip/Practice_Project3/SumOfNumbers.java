package Practice_Project3;

import java.util.Scanner;

public class SumOfNumbers {
	
	public static int sum(int n) {
		int sum = (n*(n+1))/2;
		return sum;
	}
	
	public static int sumInRange(int l, int r) {
		
		//sum of elements till right range
		int right = sum(r);
		
		//sum of elements smaller than left 
		int left = sum(l-1);
		int res = right - left;
		return res;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter left number");
		int l = sc.nextInt();
		
		System.out.println("Enter left number");
		int r = sc.nextInt();
		
		System.out.println("Sum of numbers between "+l+" and " +r+ " = "+sumInRange(l, r));
		
	}

}
