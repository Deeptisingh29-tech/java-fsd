package Practice_Project3;

import java.util.Scanner;

public class ArrayRotation {
	
	public static void rightRotate(int[] arr, int step, int n) {
		
		//if the steps are greater than size of array
			step = step%n;
			
			for(int i =0; i<n; i++) {
				if(i < step) {
					System.out.print(arr[n+i-step] +" ");  //printing the rightmost kth element
				}
				else {
					System.out.print(arr[i-step] +" ");		//printing array after positioning of k elements
				}
			}
			System.out.println();
		}
	

	public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
			System.out.print("Enter length of array ");
			int n = sc.nextInt();
			int step = 5;
			System.out.print("Enter elements of array ");
			int arr[] = new int[n];
			for(int i=0; i<n;i++) {
				arr[i] = sc.nextInt();
			}
		
		    rightRotate(arr, step, n);
		
		
			

	}

}
