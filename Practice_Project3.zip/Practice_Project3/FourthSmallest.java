package Practice_Project3;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class FourthSmallest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of array");
		int n = sc.nextInt();
		int k = 4;
		
		int arr[] = new int[n];
		System.out.println("Enter elements of array");
		for(int i=0; i<n; i++) {
			arr[i] = sc.nextInt();
		}
		
		k = k-1;		//since the array index from 0
		
		//tree set is used here to automaticaly store elements in sorted form
		Set<Integer> res = new TreeSet<Integer>();
		
		for(int j=0; j<n; j++) {
			res.add(arr[j]);
		}
		
		//to traverse the set iterator is used
		Iterator<Integer> itr = res.iterator();
		
		while(k>0) {
			itr.next();
			k--;
		}//here iitr points to kth element in the treeset
		System.out.println(itr.next());

	}

}
